<?php

// Informations de connexion à la base de données
define('DB_HOST', 'mysql-php2025-mulugeta-chatelard.alwaysdata.net');
define('DB_NAME', 'php2025-mulugeta-chatelard_projet');
define('DB_USER', '442044');
define('DB_PASS', 'Qwerty@123');
