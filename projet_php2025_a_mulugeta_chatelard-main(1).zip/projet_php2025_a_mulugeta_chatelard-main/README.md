# PROJET PHP - GESTION D'ÉQUIPE SPORTIVE

Noms des étudiants :

- MULUGETA Leul Nebeyu
- CHATELARD Mathias

Groupe : A
Date : 18 Janvier 2026

## DESCRIPTION

Ce projet est une application web permettant à un entraîneur de gérer son effectif de joueurs,
planifier des rencontres, composer ses feuilles de matchs et analyser les statistiques de son équipe.

## IDENTIFIANTS DE TEST (ENTRAÎNEUR)

Login : coach@equipe.fr
Password : motdepasse

## FONCTIONNALITÉS CLÉS RÉALISÉES

1. Authentification sécurisée (Hashage mot de passe).
2. CRUD complet Joueurs et Rencontres.
3. Gestion avancée des feuilles de match :
    - Vérification des règles (11 titulaires, 1 gardien, max 7 remplaçants).
    - Impossible de modifier une feuille de match passée.
4. Système de notation/évaluation des joueurs après match.
5. Statistiques détaillées (collectives et individuelles).
6. Architecture MVC et utilisation de PDO pour la sécurité.
