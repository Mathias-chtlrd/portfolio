# Mini-Projet Flutter

_Projet réalisé dans le cadre du module R4.A.11._

> **IMPORTANT :** Merci de remplir la fiche d'identification ci-dessous sans modifier les libellés de la colonne "Donnée".
> **NE PAS MODIFIER** la structure du tableau au-dessus de la ligne de séparation.
> Renseignez vos informations manuellement à la place des textes entre crochets `[...]`.

## 📋 Fiche d'identification

| Donnée              | Valeur     |
| :------------------ | :--------- |
| **Application**     | [Pulsar]   |
| **Numéro d'équipe** | [équipe 5] |
| **Identifiant 1**   | [dnn5210a] |
| **Identifiant 2**   | [chm5349a] |

---

Projet par Nathanael Daunis & Mathias Chatelard

## 📝 Description du Projet

Application Horloge basique (type app natives), implémente une horloge avec plusieurs fuseaux horaires (implémenter au moins FR/US), un chronomètre, des alarmes configurable et un minuteur, l'app garde en mémoires les préférences utilisateur, les temps des chronos et les alarmes configurées

---

## Fonctionnalités implémentées & conseil d'utilisation

Ecran horloge : affiche simplement l'heure et la date du système / fuseaux horaire encore non implémentée
Ecran minuteur : affiche un décompte qui affichera une popup (pour l'instant) a son terme, le bouton play/pause permet de lancer/arreter le défilement de minuteur, le bouton redémarrer arrete le défilement et remet le minuteur au dernier temps choisi (par default 5min); le bouton modifier permet de choisir le temps du minuteur, chaque unité temporelle et modifiable individuellement
Ecran alarme : permet de configurer des alarmes, chaque alarme est activable/désactivable avec un bouton on/off et reconfigurable en cliquant dessus, ce qui ouvrira un écran de paramétrage avec le choix de l'horaire en cliquant sur l'heure, le choix du nom en cliquant sur le champs de texte et le choix des jours en cliquant sur chacun des boutons correspondant a une journée de la semaine; le même écran est ouvert lorsque on clique sur le bouton "+" pour ajouter une nouvelle alarme; pour l'intant les alarmes ne produise aucun sons ou popup lorsque elles devrais sonner -> encore a implémenté
Ecran chronomètre : affiche le chronomètre ainsi que les "temps du chrono"; le bouton play/pause permet de démarrer/arreter le chrono;
le bouton tour (icone de drapeau) permet d'enregistrer le temps du chrono a un instant T et affiche le temps total du chrono, le temps depuis le dernier tour et le numéro du tour; le bouton redémarrer permet de remettre le temps du chrono a zéro.

---

## Note pour dev : implémentation des contraintes techniques

- 4 écrans -> chrono,horloge,alarme,minuteur (+ 1 ecran d'acceuil ?)
- passage vers écran cible & passage en retour vers l’écran d’origine -> config alarmes et minuteur :
  Écran principal → ouvre écran config (envoie données si modif d'alarme/minuteur déja existant)
  L’utilisateur configure/modifie l'alarme/le minutuer
  Écran config → renvoie résultat (ferme écran config)
  Écran principal → met à jour UI
- accès principal, barre de nav -> Bouton | config/suppression alarmes/minuteur -> Widget avec évènement
- acces secondaire -> appbar avec parametre / mute / a propos
- données utilisateur manipulées -> saisie manuelle alarme et minuteur, nommer une alarme enregistré
- liste d’éléments -> liste des alarmes & minuteur enregistrés, action possible sur les elt pour les suppr/modifier
- 2 language FR/EN -> implémenter les fuseau horaires
- Orientation Portrait/Paysage (min 1 ecran) implémentation a definir / toute l'appli marche au deux format ?
- Gestion d’un état local -> etat : chronos/alarme en cour/a venir (donnée durée + on/off), changement d'etat -> affichage durée et animation quand alarme ce déclenche
- Gestion d’un état global -> param utilisateur : mode clair/sombre,
- persistance des données

**Bouton de changement de langue (FR/EN) :**
Le bouton en haut à droite de l'écran horloge permet de changer la langue de toute
l'application en temps réel, sans redémarrage.

**Comment ça marche :**
Le principe c'est de garder la langue active dans le state du widget racine (MainApp).
On a transformé MainApp en StatefulWidget pour pouvoir stocker la Locale courante
et la modifier avec un setState. On expose ensuite une méthode setLocale() que
n'importe quel écran peut appeler via MainApp.of(context) ensuite Flutter remonte tout seul
l'arbre de widgets pour trouver le bon state.

Pour les traductions, on a utilisé le système intégré de Flutter (flutter_localizations + intl) :
on écrit les textes dans des fichiers .arb (un par langue), on lance flutter gen-l10n
et Flutter génère les classes Dart correspondantes automatiquement. Dans le code,
on remplace les strings en dur par AppLocalizations.of(context)!.maCle.

Au final, un tap sur le bouton -> setLocale() -> setState sur le MaterialApp →
Flutter rebuild toute l'interface dans la nouvelle langue de A à Z.

## 🚀 Guide de démarrage / Informations utiles

Ecrivez ici tout ce qui peut être utile à la compilation ou au lancement de l'application.
Commandes spécifiques, comptes de test (login/mdp), etc.
