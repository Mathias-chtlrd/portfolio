import 'dart:math' as math;
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import '../l10n/app_localizations.dart';

// Source qui a déclenché la sonnerie
enum RingSource { timer, alarm }

class RingScreen extends StatefulWidget {
  final RingSource source;
  final String? alarmLabel; // Nom de l'alarme (null si c'est le minuteur)

  const RingScreen({
    super.key,
    required this.source,
    this.alarmLabel,
  });

  @override
  State<RingScreen> createState() => _RingScreenState();
}

class _RingScreenState extends State<RingScreen>
    with TickerProviderStateMixin {

  // =========================================================================
  // ANIMATIONS
  // =========================================================================

  // Animation principale : le pulsar qui grossit et rétrécit
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  // Animation des anneaux qui s'étendent vers l'extérieur
  late AnimationController _ringsController;
  late Animation<double> _ringsAnimation;

  // =========================================================================
  // SON
  // =========================================================================

  final AudioPlayer _audioPlayer = AudioPlayer();

  // =========================================================================
  // INIT / DISPOSE
  // =========================================================================

  @override
  void initState() {
    super.initState();
    _setupAnimations();
    _playSound();
  }

  void _setupAnimations() {
    // Pulsation de l'étoile : grossit et rétrécit en boucle
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true); // reverse : fait l'aller-retour automatiquement

    _pulseAnimation = Tween<double>(begin: 0.85, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    // Anneaux qui s'étendent et disparaissent
    _ringsController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(); // repart depuis le début en boucle

    _ringsAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _ringsController, curve: Curves.easeOut),
    );
  }

  Future<void> _playSound() async {
    // Lecture en boucle du son d'alarme
    await _audioPlayer.setReleaseMode(ReleaseMode.loop);
    await _audioPlayer.play(AssetSource('sounds/alarm.mp3'));
  }

  Future<void> _stop() async {
    await _audioPlayer.stop();
    if (mounted) Navigator.pop(context);
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _ringsController.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }

  // =========================================================================
  // BUILD
  // =========================================================================

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    // Texte affiché selon la source
    final String sourceLabel = widget.source == RingSource.timer
        ? l10n.ringTimer
        : '${l10n.ringAlarm}${widget.alarmLabel != null ? ' — ${widget.alarmLabel}' : ''}';

    return Scaffold(
      backgroundColor: const Color(0xFF0D1B2E),
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Spacer(),

              // ---- Titre source ----
              Text(
                sourceLabel,
                style: const TextStyle(
                  color: Color(0xFF7A9CC0),
                  fontSize: 18,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 60),

              // ---- Pulsar animé ----
              SizedBox(
                width: 260,
                height: 260,
                child: AnimatedBuilder(
                  // AnimatedBuilder reconstruit uniquement ce widget à chaque frame
                  animation: Listenable.merge([_pulseAnimation, _ringsAnimation]),
                  builder: (context, _) {
                    return CustomPaint(
                      painter: _PulsarPainter(
                        pulseScale: _pulseAnimation.value,
                        ringsProgress: _ringsAnimation.value,
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 60),

              // ---- Heure actuelle ----
              _CurrentTime(),

              const Spacer(),

              // ---- Bouton stop ----
              Padding(
                padding: const EdgeInsets.only(bottom: 60),
                child: GestureDetector(
                  onTap: _stop,
                  child: Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A6EFF),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: const Color(0xFF1A6EFF).withValues(alpha: 0.3),
                        width: 8,
                      ),
                    ),
                    child: const Icon(
                      Icons.stop_rounded,
                      color: Colors.white,
                      size: 36,
                    ),
                  ),
                ),
              ),

              Text(
                l10n.ringStop,
                style: const TextStyle(
                  color: Color(0xFF7A9CC0),
                  fontSize: 13,
                  letterSpacing: 1.5,
                ),
              ),
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }
}

// =========================================================================
// WIDGET HEURE ACTUELLE
// =========================================================================

class _CurrentTime extends StatefulWidget {
  @override
  State<_CurrentTime> createState() => _CurrentTimeState();
}

class _CurrentTimeState extends State<_CurrentTime> {
  DateTime _now = DateTime.now();

  @override
  void initState() {
    super.initState();
    // Mise à jour chaque seconde pour afficher l'heure en direct
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 1));
      if (!mounted) return false;
      setState(() => _now = DateTime.now());
      return true;
    });
  }

  @override
  Widget build(BuildContext context) {
    final h = _now.hour.toString().padLeft(2, '0');
    final m = _now.minute.toString().padLeft(2, '0');
    return Text(
      '$h:$m',
      style: const TextStyle(
        color: Colors.white,
        fontSize: 64,
        fontWeight: FontWeight.w200,
        letterSpacing: 4,
      ),
    );
  }
}

// =========================================================================
// CUSTOM PAINTER : ÉTOILE PULSAR + ANNEAUX
// =========================================================================

class _PulsarPainter extends CustomPainter {
  final double pulseScale; // 0.85 → 1.0 : taille de l'étoile
  final double ringsProgress; // 0.0 → 1.0 : expansion des anneaux

  _PulsarPainter({required this.pulseScale, required this.ringsProgress});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final maxRadius = size.width / 2;

    // ---- Anneaux qui s'étendent et s'estompent ----
    // On dessine 3 anneaux décalés dans le temps
    for (int i = 0; i < 3; i++) {
      // Chaque anneau est décalé d'un tiers de cycle
      final offset = i / 3.0;
      final progress = (ringsProgress + offset) % 1.0;

      // L'anneau grandit de 40% à 100% du rayon max
      final ringRadius = maxRadius * (0.4 + progress * 0.6);

      // L'opacité diminue au fur et à mesure que l'anneau grandit
      final opacity = (1.0 - progress) * 0.35;

      canvas.drawCircle(
        center,
        ringRadius,
        Paint()
          ..color = const Color(0xFF1A6EFF).withValues(alpha: opacity)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2,
      );
    }

    // ---- Halo central doux ----
    canvas.drawCircle(
      center,
      maxRadius * 0.42 * pulseScale,
      Paint()..color = const Color(0xFF1A6EFF).withValues(alpha: 0.12),
    );

    // ---- Étoile à 8 branches ----
    _drawStar(canvas, center, maxRadius * 0.35 * pulseScale);

    // ---- Point central ----
    canvas.drawCircle(
      center,
      6 * pulseScale,
      Paint()..color = Colors.white,
    );
  }

  /// Dessine une étoile à [branches] branches centrée sur [center]
  void _drawStar(Canvas canvas, Offset center, double outerRadius) {
    const branches = 8;
    // Rayon intérieur (creux entre les branches) = 45% du rayon extérieur
    final innerRadius = outerRadius * 0.45;

    final path = Path();
    for (int i = 0; i < branches * 2; i++) {
      // On alterne rayon extérieur (pointe) et intérieur (creux)
      final radius = i.isEven ? outerRadius : innerRadius;
      // Angle de départ : -π/2 pour que la première pointe soit en haut
      final angle = (math.pi / branches) * i - math.pi / 2;
      final x = center.dx + radius * math.cos(angle);
      final y = center.dy + radius * math.sin(angle);

      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    path.close();

    // Remplissage bleu de l'étoile
    canvas.drawPath(
      path,
      Paint()..color = const Color(0xFF1A6EFF),
    );

    // Contour blanc fin pour le détail
    canvas.drawPath(
      path,
      Paint()
        ..color = Colors.white.withValues(alpha: 0.25)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5
        ..strokeJoin = StrokeJoin.round,
    );
  }

  // On redessine à chaque frame (les valeurs changent en continu)
  @override
  bool shouldRepaint(_PulsarPainter old) =>
      old.pulseScale != pulseScale || old.ringsProgress != ringsProgress;
}