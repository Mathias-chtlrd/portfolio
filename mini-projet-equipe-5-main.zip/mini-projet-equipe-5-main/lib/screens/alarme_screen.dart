import 'dart:convert';
import 'dart:async';
import 'sonnerie_screen.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../l10n/app_localizations.dart';

/// Modèle de données représentant une alarme
class Alarm {
  String time; // Heure au format "HH:mm"
  String label; // Nom de l'alarme
  bool isActive; // État actif/inactif
  List<bool> days; // Jours de répétition : index 0 = lundi, 6 = dimanche

  Alarm({
    required this.time,
    required this.label,
    this.isActive = true,
    required this.days,
  });

  /// Convertit l'alarme en Map pour la sérialisation JSON
  Map<String, dynamic> toJson() => {
    'time': time,
    'label': label,
    'isActive': isActive,
    'days': days,
  };

  /// Reconstruit une alarme depuis une Map JSON
  factory Alarm.fromJson(Map<String, dynamic> json) => Alarm(
    time: json['time'],
    label: json['label'],
    isActive: json['isActive'],
    days: List<bool>.from(json['days']),
  );
}

class AlarmScreen extends StatefulWidget {
  const AlarmScreen({super.key});

  @override
  State<AlarmScreen> createState() => _AlarmScreenState();
}

class _AlarmScreenState extends State<AlarmScreen> {
  List<Alarm> alarms = [];
  Timer? _checkTimer;

  @override
  void initState() {
    super.initState();
    _loadAlarms();
    _checkTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      _checkAlarms();
    });
  }

  @override
  void dispose() {
    _checkTimer?.cancel();
    super.dispose();
  }

  void _checkAlarms() {
    final now = TimeOfDay.now();
    final currentTime =
        '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';

    for (final alarm in alarms) {
      if (alarm.isActive && alarm.time == currentTime) {
        if (mounted) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => RingScreen(
                source: RingSource.alarm,
                alarmLabel: alarm.label,
              ),
            ),
          );
        }
        break; // Une seule sonnerie à la fois
      }
    }
  }

  /// Charge les alarmes sauvegardées depuis le stockage local
  Future<void> _loadAlarms() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('alarms');
    if (raw != null) {
      final List decoded = jsonDecode(raw);
      setState(() => alarms = decoded.map((e) => Alarm.fromJson(e)).toList());
    }
  }

  /// Sauvegarde la liste d'alarmes dans le stockage local au format JSON
  Future<void> _saveAlarms() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString(
      'alarms',
      jsonEncode(alarms.map((a) => a.toJson()).toList()),
    );
  }

  /// Ouvre le panel de réglages en création (index null) ou en édition (index fourni)
  void _openAlarmSettings({Alarm? existingAlarm, int? index}) {
    final l10n = AppLocalizations.of(context)!;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _AlarmSettingsSheet(
        alarm: existingAlarm,
        // On passe le label par défaut localisé pour qu'il soit correct
        // peu importe la langue active au moment de la création
        defaultLabel: l10n.alarmDefaultLabel,
        onSave: (newAlarm) {
          setState(() {
            if (index == null) {
              alarms.add(newAlarm);
            } else {
              alarms[index] = newAlarm;
            }
          });
          _saveAlarms();
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return Scaffold(
      backgroundColor: const Color(0xFF0D1B2E),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xFF1A6EFF),
        elevation: 10,
        tooltip: l10n.addAlarm,
        child: const Icon(Icons.add, color: Colors.white, size: 30),
        onPressed: () => _openAlarmSettings(),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 60),
            Text(
              l10n.alarmScreenTitle,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 36,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: alarms.length,
                itemBuilder: (context, index) {
                  final item = alarms[index];
                  return _buildAlarmCard(item, index);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Construit la carte d'affichage d'une alarme
  Widget _buildAlarmCard(Alarm item, int index) {
    return GestureDetector(
      onTap: () => _openAlarmSettings(existingAlarm: item, index: index),
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: const Color(0xFF122540),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: item.isActive
                ? const Color(0xFF1A6EFF).withValues(alpha: 0.3)
                : Colors.transparent,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.time,
                  style: TextStyle(
                    color: item.isActive
                        ? Colors.white
                        : const Color(0xFF7A9CC0),
                    fontSize: 32,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  item.label,
                  style: const TextStyle(
                    color: Color(0xFF7A9CC0),
                    fontSize: 14,
                  ),
                ),
              ],
            ),
            Switch(
              value: item.isActive,
              activeThumbColor: const Color(0xFF1A6EFF),
              activeTrackColor: const Color(0xFF1A6EFF).withValues(alpha: 0.3),
              inactiveThumbColor: const Color(0xFF7A9CC0),
              onChanged: (val) {
                setState(() => item.isActive = val);
                _saveAlarms();
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _AlarmSettingsSheet extends StatefulWidget {
  final Alarm? alarm;
  final String defaultLabel; // Label par défaut localisé, fourni par le parent
  final Function(Alarm) onSave;

  const _AlarmSettingsSheet({
    this.alarm,
    required this.defaultLabel,
    required this.onSave,
  });

  @override
  State<_AlarmSettingsSheet> createState() => _AlarmSettingsSheetState();
}

class _AlarmSettingsSheetState extends State<_AlarmSettingsSheet> {
  late TimeOfDay selectedTime;
  late TextEditingController labelController;
  late List<bool> selectedDays;

  @override
  void initState() {
    super.initState();
    if (widget.alarm != null) {
      final parts = widget.alarm!.time.split(':');
      selectedTime = TimeOfDay(
        hour: int.parse(parts[0]),
        minute: int.parse(parts[1]),
      );
      labelController = TextEditingController(text: widget.alarm!.label);
      selectedDays = List.from(widget.alarm!.days);
    } else {
      selectedTime = const TimeOfDay(hour: 08, minute: 00);
      // Utilise le label localisé passé en paramètre
      labelController = TextEditingController(text: widget.defaultLabel);
      selectedDays = List.generate(7, (index) => false);
    }
  }

  @override
  void dispose() {
    labelController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF0D1B2E),
        borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
      child: Wrap(
        children: [
          Column(
            children: [
              // Barre : Annuler / Titre / Enregistrer
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: Text(
                      l10n.alarmCancel,
                      style: const TextStyle(color: Color(0xFF7A9CC0)),
                    ),
                  ),
                  Text(
                    l10n.alarmSettingsTitle,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      widget.onSave(
                        Alarm(
                          time:
                              "${selectedTime.hour.toString().padLeft(2, '0')}:${selectedTime.minute.toString().padLeft(2, '0')}",
                          label: labelController.text,
                          days: selectedDays,
                        ),
                      );
                      Navigator.pop(context);
                    },
                    child: Text(
                      l10n.alarmSave,
                      style: const TextStyle(
                        color: Color(0xFF1A6EFF),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 30),
              // Affichage de l'heure — tap pour ouvrir le sélecteur natif
              GestureDetector(
                onTap: () async {
                  final time = await showTimePicker(
                    context: context,
                    initialTime: selectedTime,
                    builder: (context, child) => Theme(
                      data: ThemeData.dark().copyWith(
                        colorScheme: const ColorScheme.dark(
                          primary: Color(0xFF1A6EFF),
                        ),
                      ),
                      child: child!,
                    ),
                  );
                  if (time != null) setState(() => selectedTime = time);
                },
                child: Text(
                  "${selectedTime.hour.toString().padLeft(2, '0')}:${selectedTime.minute.toString().padLeft(2, '0')}",
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 80,
                    fontWeight: FontWeight.w200,
                  ),
                ),
              ),
              const SizedBox(height: 30),
              // Champ de saisie pour le nom de l'alarme
              TextField(
                controller: labelController,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  filled: true,
                  fillColor: const Color(0xFF122540),
                  hintText: l10n.alarmNameHint,
                  hintStyle: const TextStyle(color: Color(0xFF7A9CC0)),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
              const SizedBox(height: 30),
              // Sélecteur des jours de répétition (L M M J V S D)
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: List.generate(7, (index) {
                  final dayLabels = l10n.dayLabels.split(',');
                  bool isSelected = selectedDays[index];
                  return GestureDetector(
                    onTap: () =>
                        setState(() => selectedDays[index] = !isSelected),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: isSelected
                            ? const Color(0xFF1A6EFF)
                            : const Color(0xFF122540),
                        shape: BoxShape.circle,
                      ),
                      child: Center(
                        child: Text(
                          dayLabels[index],
                          style: TextStyle(
                            color: isSelected
                                ? Colors.white
                                : const Color(0xFF7A9CC0),
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  );
                }),
              ),
              const SizedBox(height: 40),
            ],
          ),
        ],
      ),
    );
  }
}
