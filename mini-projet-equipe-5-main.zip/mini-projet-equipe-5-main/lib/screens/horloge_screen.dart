import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../main.dart';

class HorlogeScreen extends StatefulWidget {
  const HorlogeScreen({super.key});
  @override
  State<HorlogeScreen> createState() => _HorlogeScreenState();
}

class _HorlogeScreenState extends State<HorlogeScreen> {
  DateTime _now = DateTime.now();
  late Timer _clockTimer;

  @override
  void initState() {
    super.initState();
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() {
        _now = DateTime.now();
      });
    });
  }

  @override
  void dispose() {
    _clockTimer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final h = _now.hour.toString().padLeft(2, '0');
    final m = _now.minute.toString().padLeft(2, '0');
    final s = _now.second.toString().padLeft(2, '0');
    final timeString = '$h:$m:$s';

    final isFrench = Localizations.localeOf(context).languageCode == 'fr';

    return Scaffold(
      backgroundColor: const Color(0xFF0D1B2E),
      body: Stack(
        children: [
          // Bouton de langue en haut à droite
          Positioned(
            top: 50,
            right: 20,
            child: GestureDetector(
              onTap: () {
                MainApp.of(
                  context,
                ).setLocale(isFrench ? const Locale('en') : const Locale('fr'));
              },
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFF122540),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: const Color(0xFF1A6EFF).withValues(alpha: 0.4),
                  ),
                ),
                child: Text(
                  isFrench ? '🇬🇧 EN' : '🇫🇷 FR',
                  style: const TextStyle(
                    color: Color(0xFF7A9CC0),
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ),

          // Contenu principal centré
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  width: 220,
                  height: 220,
                  child: CustomPaint(painter: _AnalogClockPainter(_now)),
                ),
                const SizedBox(height: 24),
                Text(
                  timeString,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 48,
                    fontWeight: FontWeight.w200,
                    letterSpacing: 4,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  isFrench
                      ? '${_now.day}/${_now.month}/${_now.year}'
                      : '${_now.month}/${_now.day}/${_now.year}',
                  style: const TextStyle(
                    color: Color(0xFF7A9CC0),
                    fontSize: 16,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// (le CustomPainter reste identique, pas touché)
class _AnalogClockPainter extends CustomPainter {
  final DateTime now;

  _AnalogClockPainter(this.now);

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    canvas.drawCircle(center, radius, Paint()..color = const Color(0xFF122540));
    canvas.drawCircle(
      center,
      radius,
      Paint()
        ..color = const Color(0xFF1A6EFF)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2,
    );

    for (int i = 0; i < 12; i++) {
      final angle = (i * 30) * math.pi / 180;
      final isMain = i % 3 == 0;
      final outer = radius - 8;
      final inner = isMain ? radius - 22 : radius - 14;

      canvas.drawLine(
        Offset(
          center.dx + outer * math.sin(angle),
          center.dy - outer * math.cos(angle),
        ),
        Offset(
          center.dx + inner * math.sin(angle),
          center.dy - inner * math.cos(angle),
        ),
        Paint()
          ..color = isMain ? Colors.white : const Color(0xFF7A9CC0)
          ..strokeWidth = isMain ? 2.5 : 1.5
          ..strokeCap = StrokeCap.round,
      );
    }

    _drawHand(
      canvas,
      center,
      angle: ((now.hour % 12) * 30 + now.minute * 0.5) * math.pi / 180,
      length: radius * 0.5,
      width: 5,
      color: Colors.white,
    );
    _drawHand(
      canvas,
      center,
      angle: (now.minute * 6 + now.second * 0.1) * math.pi / 180,
      length: radius * 0.72,
      width: 3,
      color: Colors.white,
    );
    _drawHand(
      canvas,
      center,
      angle: now.second * 6 * math.pi / 180,
      length: radius * 0.78,
      width: 1.5,
      color: const Color(0xFF1A6EFF),
    );

    canvas.drawCircle(center, 6, Paint()..color = const Color(0xFF1A6EFF));
  }

  void _drawHand(
    Canvas canvas,
    Offset center, {
    required double angle,
    required double length,
    required double width,
    required Color color,
  }) {
    canvas.drawLine(
      center,
      Offset(
        center.dx + length * math.sin(angle),
        center.dy - length * math.cos(angle),
      ),
      Paint()
        ..color = color
        ..strokeWidth = width
        ..strokeCap = StrokeCap.round,
    );
  }

  @override
  bool shouldRepaint(_AnalogClockPainter old) => old.now.second != now.second;
}
