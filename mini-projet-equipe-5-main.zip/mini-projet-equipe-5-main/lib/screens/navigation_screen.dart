import 'package:flutter/material.dart';
import 'horloge_screen.dart';
import 'minuteur_screen.dart';
import 'alarme_screen.dart';
import 'chrono_screen.dart';
import '../l10n/app_localizations.dart';

class NavBarScreen extends StatefulWidget {
  const NavBarScreen({super.key});

  @override
  State<NavBarScreen> createState() => _NavBarScreenState();
}

class _NavBarScreenState extends State<NavBarScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = const [
    HorlogeScreen(),
    TimerScreen(),
    AlarmScreen(),
    StopwatchScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return Scaffold(
      backgroundColor: const Color(0xFF0D1B2E),

      // IndexedStack garde les écrans en mémoire, permet à certaines fonctionnalités de tourner
      // même si l'écran n'est pas affiché
      body: IndexedStack(index: _currentIndex, children: _screens),

      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: Color(0xFF0D1B2E),
          border: Border(top: BorderSide(color: Color(0xFF1E3555), width: 1)),
        ),
        child: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (index) => setState(() => _currentIndex = index),
          backgroundColor: Colors.transparent,
          elevation: 0,
          type: BottomNavigationBarType.fixed,
          selectedItemColor: const Color(0xFF1A6EFF),
          unselectedItemColor: const Color(0xFF7A9CC0),
          selectedLabelStyle: const TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w600,
          ),
          unselectedLabelStyle: const TextStyle(fontSize: 11),
          items: [
            BottomNavigationBarItem(
              icon: const Icon(Icons.access_time_outlined),
              activeIcon: const Icon(Icons.access_time_filled),
              label: l10n.tabClock,
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.timer_outlined),
              activeIcon: const Icon(Icons.timer),
              label: l10n.tabTimer,
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.alarm_outlined),
              activeIcon: const Icon(Icons.alarm),
              label: l10n.tabAlarm,
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.stop_circle_outlined),
              activeIcon: const Icon(Icons.stop_circle),
              label: l10n.tabChrono,
            ),
          ],
        ),
      ),
    );
  }
}
