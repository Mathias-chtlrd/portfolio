import 'dart:async';
import 'sonnerie_screen.dart';
import 'package:flutter/material.dart';
import '../l10n/app_localizations.dart';

class TimerScreen extends StatefulWidget {
  const TimerScreen({super.key});

  @override
  State<TimerScreen> createState() => _TimerScreenState();
}

class _TimerScreenState extends State<TimerScreen> {
  Timer? _timer;
  Duration _initialDuration = const Duration(minutes: 5);
  Duration _remainingTime = const Duration(minutes: 5);
  bool _isRunning = false;

  void _toggleTimer() {
    if (_isRunning) {
      _stopTimer();
    } else {
      _startTimer();
    }
  }

  void _startTimer() {
    if (_remainingTime.inSeconds > 0) {
      setState(() => _isRunning = true);
      _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
        setState(() {
          if (_remainingTime.inSeconds > 0) {
            _remainingTime -= const Duration(seconds: 1);
          } else {
            _stopTimer();
            _showRingScreen();
          }
        });
      });
    }
  }

  void _stopTimer() {
    _timer?.cancel();
    setState(() => _isRunning = false);
  }

  void _resetTimer() {
    _stopTimer();
    setState(() => _remainingTime = _initialDuration);
  }

  void _showRingScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const RingScreen(source: RingSource.timer),
      ),
    );
  }

  void _showPicker() {
    final l10n = AppLocalizations.of(context)!;
    int hours = _initialDuration.inHours;
    int minutes = _initialDuration.inMinutes % 60;
    int seconds = _initialDuration.inSeconds % 60;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF0D1B2E),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
      ),
      builder: (context) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
        ),
        child: Container(
          padding: const EdgeInsets.all(30),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                l10n.timerSetDuration,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 30),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildTimeInput(l10n.timerHours, hours, (v) => hours = v),
                  _buildTimeInput(
                    l10n.timerMinutes,
                    minutes,
                    (v) => minutes = v,
                  ),
                  _buildTimeInput(
                    l10n.timerSeconds,
                    seconds,
                    (v) => seconds = v,
                  ),
                ],
              ),
              const SizedBox(height: 40),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1A6EFF),
                  minimumSize: const Size(double.infinity, 55),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                ),
                onPressed: () {
                  if (hours > 99) hours = 99;
                  if (hours < 0) hours = 0;
                  if (minutes > 59) minutes = 59;
                  if (minutes < 0) minutes = 0;
                  if (seconds > 59) seconds = 59;
                  if (seconds < 0) seconds = 0;

                  setState(() {
                    _initialDuration = Duration(
                      hours: hours,
                      minutes: minutes,
                      seconds: seconds,
                    );
                    _remainingTime = _initialDuration;
                  });
                  Navigator.pop(context);
                },
                child: Text(
                  l10n.timerValidate,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTimeInput(
    String label,
    int initialValue,
    Function(int) onChanged,
  ) {
    return Column(
      children: [
        SizedBox(
          width: 70,
          child: TextField(
            keyboardType: TextInputType.number,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 28,
              fontWeight: FontWeight.bold,
            ),
            decoration: const InputDecoration(
              enabledBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: Color(0xFF122540)),
              ),
              focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: Color(0xFF1A6EFF)),
              ),
            ),
            controller: TextEditingController(
              text: initialValue.toString().padLeft(2, '0'),
            ),
            onChanged: (v) => onChanged(int.tryParse(v) ?? 0),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: const TextStyle(color: Color(0xFF7A9CC0), fontSize: 12),
        ),
      ],
    );
  }

  String _formatDuration(Duration d) {
    String h = d.inHours.toString().padLeft(2, '0');
    String m = (d.inMinutes % 60).toString().padLeft(2, '0');
    String s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return d.inHours > 0 ? "$h:$m:$s" : "$m:$s";
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    double progress = _initialDuration.inSeconds > 0
        ? _remainingTime.inSeconds / _initialDuration.inSeconds
        : 0;

    return Scaffold(
      backgroundColor: const Color(0xFF0D1B2E),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            GestureDetector(
              onTap: _isRunning ? null : _showPicker,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox(
                    width: 260,
                    height: 260,
                    child: CircularProgressIndicator(
                      value: progress,
                      strokeWidth: 8,
                      backgroundColor: const Color(0xFF122540),
                      valueColor: const AlwaysStoppedAnimation<Color>(
                        Color(0xFF1A6EFF),
                      ),
                    ),
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        _formatDuration(_remainingTime),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 60,
                          fontWeight: FontWeight.w200,
                        ),
                      ),
                      if (!_isRunning)
                        Text(
                          l10n.timerEdit,
                          style: const TextStyle(
                            color: Color(0xFF1A6EFF),
                            letterSpacing: 2,
                            fontSize: 12,
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 80),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _circularButton(
                  icon: _isRunning ? Icons.pause : Icons.play_arrow,
                  color: const Color(0xFF1A6EFF),
                  onTap: _toggleTimer,
                ),
                const SizedBox(width: 30),
                _circularButton(
                  icon: Icons.refresh,
                  color: const Color(0xFF122540),
                  onTap: _resetTimer,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _circularButton({
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: CircleAvatar(
        radius: 35,
        backgroundColor: color,
        child: Icon(icon, color: Colors.white, size: 30),
      ),
    );
  }
}
