import 'dart:async';
import 'package:flutter/material.dart';
import '../l10n/app_localizations.dart';

class StopwatchScreen extends StatefulWidget {
  const StopwatchScreen({super.key});

  @override
  State<StopwatchScreen> createState() => _StopwatchScreenState();
}

class _StopwatchScreenState extends State<StopwatchScreen> {
  final Stopwatch _stopwatch = Stopwatch();
  late Timer _timer;

  // Liste d'objets pour stocker le temps total et le temps du tour
  final List<Map<String, Duration>> _laps = [];

  void _toggleStopwatch() {
    setState(() {
      if (_stopwatch.isRunning) {
        _stopwatch.stop();
      } else {
        _stopwatch.start();
        _timer = Timer.periodic(const Duration(milliseconds: 30), (timer) {
          setState(() {});
        });
      }
    });
  }

  void _resetStopwatch() {
    setState(() {
      _stopwatch.reset();
      _laps.clear();
    });
  }

  void _recordLap() {
    if (_stopwatch.isRunning) {
      setState(() {
        final totalDuration = _stopwatch.elapsed;
        Duration lapDuration;

        if (_laps.isEmpty) {
          // Premier tour : le temps du tour est égal au temps total
          lapDuration = totalDuration;
        } else {
          // Tours suivants : temps total actuel - temps total du tour précédent
          final previousTotal = _laps.first['total']!;
          lapDuration = totalDuration - previousTotal;
        }

        _laps.insert(0, {'total': totalDuration, 'lap': lapDuration});
      });
    }
  }

  // Fonction utilitaire pour formater une Duration en String
  String _formatDuration(Duration duration) {
    final milli = duration.inMilliseconds;
    final sec = (milli / 1000).truncate();
    final min = (sec / 60).truncate();
    final displayMil = (milli % 1000 / 10).truncate().toString().padLeft(
      2,
      '0',
    );
    final displaySec = (sec % 60).toString().padLeft(2, '0');
    final displayMin = (min % 60).toString().padLeft(2, '0');
    return "$displayMin:$displaySec:$displayMil";
  }

  @override
  void dispose() {
    _timer.cancel();
    _stopwatch.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return Scaffold(
      backgroundColor: const Color(0xFF0D1B2E),
      body: Column(
        children: [
          const SizedBox(height: 80),
          // Temps principal
          Text(
            _formatDuration(_stopwatch.elapsed),
            style: const TextStyle(
              color: Colors.white,
              fontSize: 72,
              fontWeight: FontWeight.w200,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 40),
          // Boutons
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildButton(
                icon: _stopwatch.isRunning ? Icons.pause : Icons.play_arrow,
                onTap: _toggleStopwatch,
                color: const Color(0xFF1A6EFF),
              ),
              const SizedBox(width: 20),
              _buildButton(
                icon: Icons.flag,
                onTap: _recordLap,
                color: const Color(0xFF122540),
              ),
              const SizedBox(width: 20),
              _buildButton(
                icon: Icons.refresh,
                onTap: _resetStopwatch,
                color: const Color(0xFF122540),
              ),
            ],
          ),
          const SizedBox(height: 30),
          // En-tête de liste
          if (_laps.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    l10n.chronoLapLabel,
                    style: const TextStyle(
                      color: Color(0xFF7A9CC0),
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    l10n.chronoLapTime,
                    style: const TextStyle(
                      color: Color(0xFF7A9CC0),
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    l10n.chronoTotal,
                    style: const TextStyle(
                      color: Color(0xFF7A9CC0),
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          // Liste des temps
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 30),
              itemCount: _laps.length,
              itemBuilder: (context, index) {
                final lapData = _laps[index];
                return Container(
                  margin: const EdgeInsets.symmetric(vertical: 4),
                  padding: const EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    color: const Color(0xFF122540).withOpacity(0.4),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      Text(
                        "${_laps.length - index}".padLeft(2, '0'),
                        style: const TextStyle(
                          color: Color(0xFF1A6EFF),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const Spacer(),
                      Text(
                        _formatDuration(lapData['lap']!),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontFamily: 'monospace',
                        ),
                      ),
                      const Spacer(),
                      Text(
                        _formatDuration(lapData['total']!),
                        style: const TextStyle(
                          color: Color(0xFF7A9CC0),
                          fontSize: 16,
                          fontFamily: 'monospace',
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildButton({
    required IconData icon,
    required VoidCallback onTap,
    required Color color,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: CircleAvatar(
        radius: 30,
        backgroundColor: color,
        child: Icon(icon, color: Colors.white, size: 28),
      ),
    );
  }
}
