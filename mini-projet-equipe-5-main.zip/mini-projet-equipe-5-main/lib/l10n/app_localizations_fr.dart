// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for French (`fr`).
class AppLocalizationsFr extends AppLocalizations {
  AppLocalizationsFr([String locale = 'fr']) : super(locale);

  @override
  String get appTitle => 'Mon Horloge';

  @override
  String get tabClock => 'Horloge';

  @override
  String get tabTimer => 'Minuteur';

  @override
  String get tabAlarm => 'Alarme';

  @override
  String get tabChrono => 'Chrono';

  @override
  String get alarmScreenTitle => 'Alarmes';

  @override
  String get alarmDefaultLabel => 'Alarme';

  @override
  String get alarmNameHint => 'Nom de l\'alarme';

  @override
  String get alarmSettingsTitle => 'Réglages';

  @override
  String get alarmSave => 'Enregistrer';

  @override
  String get alarmCancel => 'Annuler';

  @override
  String get addAlarm => 'Ajouter une alarme';

  @override
  String get chronoLapLabel => 'TOUR';

  @override
  String get chronoLapTime => 'TEMPS TOUR';

  @override
  String get chronoTotal => 'TOTAL';

  @override
  String get timerFinished => 'Temps écoulé !';

  @override
  String get timerOk => 'OK';

  @override
  String get timerSetDuration => 'Définir la durée';

  @override
  String get timerHours => 'Heures';

  @override
  String get timerMinutes => 'Min';

  @override
  String get timerSeconds => 'Sec';

  @override
  String get timerValidate => 'VALIDER';

  @override
  String get timerEdit => 'MODIFIER';

  @override
  String get dayLabels => 'L,M,M,J,V,S,D';

  @override
  String get ringTimer => 'Minuteur terminé';

  @override
  String get ringAlarm => 'Alarme';

  @override
  String get ringStop => 'Arrêter';
}
