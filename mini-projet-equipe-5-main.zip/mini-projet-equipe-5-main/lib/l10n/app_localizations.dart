import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_en.dart';
import 'app_localizations_fr.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale)
    : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates =
      <LocalizationsDelegate<dynamic>>[
        delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('en'),
    Locale('fr'),
  ];

  /// Titre de l'application
  ///
  /// In fr, this message translates to:
  /// **'Mon Horloge'**
  String get appTitle;

  /// Onglet de l'horloge dans la barre de navigation
  ///
  /// In fr, this message translates to:
  /// **'Horloge'**
  String get tabClock;

  /// Onglet du minuteur dans la barre de navigation
  ///
  /// In fr, this message translates to:
  /// **'Minuteur'**
  String get tabTimer;

  /// Onglet des alarmes dans la barre de navigation
  ///
  /// In fr, this message translates to:
  /// **'Alarme'**
  String get tabAlarm;

  /// Onglet du chronomètre dans la barre de navigation
  ///
  /// In fr, this message translates to:
  /// **'Chrono'**
  String get tabChrono;

  /// Titre de l'écran des alarmes
  ///
  /// In fr, this message translates to:
  /// **'Alarmes'**
  String get alarmScreenTitle;

  /// Nom par défaut d'une nouvelle alarme
  ///
  /// In fr, this message translates to:
  /// **'Alarme'**
  String get alarmDefaultLabel;

  /// Placeholder du champ de saisie du nom de l'alarme
  ///
  /// In fr, this message translates to:
  /// **'Nom de l\'alarme'**
  String get alarmNameHint;

  /// Titre du panneau de réglages d'une alarme
  ///
  /// In fr, this message translates to:
  /// **'Réglages'**
  String get alarmSettingsTitle;

  /// Bouton de sauvegarde de l'alarme
  ///
  /// In fr, this message translates to:
  /// **'Enregistrer'**
  String get alarmSave;

  /// Bouton d'annulation dans le panneau de réglages
  ///
  /// In fr, this message translates to:
  /// **'Annuler'**
  String get alarmCancel;

  /// Tooltip du bouton flottant d'ajout d'alarme
  ///
  /// In fr, this message translates to:
  /// **'Ajouter une alarme'**
  String get addAlarm;

  /// En-tête de colonne numéro de tour dans le chrono
  ///
  /// In fr, this message translates to:
  /// **'TOUR'**
  String get chronoLapLabel;

  /// En-tête de colonne temps du tour dans le chrono
  ///
  /// In fr, this message translates to:
  /// **'TEMPS TOUR'**
  String get chronoLapTime;

  /// En-tête de colonne temps total dans le chrono
  ///
  /// In fr, this message translates to:
  /// **'TOTAL'**
  String get chronoTotal;

  /// Titre de la dialog quand le minuteur arrive à zéro
  ///
  /// In fr, this message translates to:
  /// **'Temps écoulé !'**
  String get timerFinished;

  /// Bouton de confirmation de la dialog de fin de minuteur
  ///
  /// In fr, this message translates to:
  /// **'OK'**
  String get timerOk;

  /// Titre du panneau de saisie de la durée du minuteur
  ///
  /// In fr, this message translates to:
  /// **'Définir la durée'**
  String get timerSetDuration;

  /// Label du champ heures dans le sélecteur de durée
  ///
  /// In fr, this message translates to:
  /// **'Heures'**
  String get timerHours;

  /// Label du champ minutes dans le sélecteur de durée
  ///
  /// In fr, this message translates to:
  /// **'Min'**
  String get timerMinutes;

  /// Label du champ secondes dans le sélecteur de durée
  ///
  /// In fr, this message translates to:
  /// **'Sec'**
  String get timerSeconds;

  /// Bouton de validation de la durée du minuteur
  ///
  /// In fr, this message translates to:
  /// **'VALIDER'**
  String get timerValidate;

  /// Indication cliquable pour modifier la durée quand le minuteur est arrêté
  ///
  /// In fr, this message translates to:
  /// **'MODIFIER'**
  String get timerEdit;

  /// Initiales des jours de la semaine séparées par des virgules (Lun à Dim)
  ///
  /// In fr, this message translates to:
  /// **'L,M,M,J,V,S,D'**
  String get dayLabels;

  ///
  ///
  /// In fr, this message translates to:
  /// **'Minuteur terminé'**
  String get ringTimer;

  ///
  ///
  /// In fr, this message translates to:
  /// **'Alarme'**
  String get ringAlarm;

  ///
  ///
  /// In fr, this message translates to:
  /// **'Arrêter'**
  String get ringStop;
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) =>
      <String>['en', 'fr'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {
  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'en':
      return AppLocalizationsEn();
    case 'fr':
      return AppLocalizationsFr();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.',
  );
}
