// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get appTitle => 'My Clock';

  @override
  String get tabClock => 'Clock';

  @override
  String get tabTimer => 'Timer';

  @override
  String get tabAlarm => 'Alarm';

  @override
  String get tabChrono => 'Stopwatch';

  @override
  String get alarmScreenTitle => 'Alarms';

  @override
  String get alarmDefaultLabel => 'Alarm';

  @override
  String get alarmNameHint => 'Alarm name';

  @override
  String get alarmSettingsTitle => 'Settings';

  @override
  String get alarmSave => 'Save';

  @override
  String get alarmCancel => 'Cancel';

  @override
  String get addAlarm => 'Add Alarm';

  @override
  String get chronoLapLabel => 'LAP';

  @override
  String get chronoLapTime => 'LAP TIME';

  @override
  String get chronoTotal => 'TOTAL';

  @override
  String get timerFinished => 'Time\'s up!';

  @override
  String get timerOk => 'OK';

  @override
  String get timerSetDuration => 'Set duration';

  @override
  String get timerHours => 'Hours';

  @override
  String get timerMinutes => 'Min';

  @override
  String get timerSeconds => 'Sec';

  @override
  String get timerValidate => 'CONFIRM';

  @override
  String get timerEdit => 'EDIT';

  @override
  String get dayLabels => 'M,T,W,T,F,S,S';

  @override
  String get ringTimer => 'Timer finished';

  @override
  String get ringAlarm => 'Alarm';

  @override
  String get ringStop => 'Stop';
}
