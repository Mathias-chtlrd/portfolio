package com.example.mini_projet.mini_projet_equipe_n

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
