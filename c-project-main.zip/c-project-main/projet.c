/******************************************************************************
*  ASR => 4R2.04                                                              *
*******************************************************************************
*                                                                             *
*  N° de Sujet : 3                                                            *
*                                                                             *
*******************************************************************************
*                                                                             *
*  Intitulé : Chiffrement de message                                          *
*                                                                             *
*******************************************************************************
*                                                                             *
*  Nom-prénom1 : Valentin Pereira Berger                                      *
*                                                                             *
*  Nom-prénom2 : Mathias Chatelard                                            *
*                                                                             *
*  Nom-prénom3 :                                                              *
*                                                                             *
*  Nom-prénom4 :                                                              *
*                                                                             *
*******************************************************************************
*                                                                             *
*  Nom du fichier : projet.c                                                  *
*                                                                             *
******************************************************************************/



#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>  



int estAlphanumerique(const char *chaine) {
    int i = 0;
    while (chaine[i] != '\n') {
        if (!isalnum(chaine[i])) {
            return 0; // Faux, il y a un caractère non alphanumérique
        }
        i++;
    }
    return 1; // Vrai, tous les caractères sont alphanumériques
}



void chiffrerCesar(char *message, int cle) {
    int i = 0;
    while (message[i] != '\0') {
        char c = message[i];

        if (c >= 'A' && c <= 'Z') {
            // Lettre majuscule
            message[i] = ((c - 'A' + cle) % 26) + 'A';
        } else if (c >= 'a' && c <= 'z') {
            // Lettre minuscule
            message[i] = ((c - 'a' + cle) % 26) + 'a';
        } else if (c >= '0' && c <= '9') {
            // Chiffre
            message[i] = ((c - '0' + cle) % 10) + '0';
        }
        // Les autres caractères (espace, ponctuation) restent inchangés
        i++;
    }
}


void dechiffrerCesar(char *message, int cle) {
    int i = 0;
    while (message[i] != '\0') {
        char c = message[i];

        if (c >= 'A' && c <= 'Z') {
            // Lettre majuscule
            message[i] = ((c - 'A' - cle + 26) % 26) + 'A';
        } else if (c >= 'a' && c <= 'z') {
            // Lettre minuscule
            message[i] = ((c - 'a' - cle + 26) % 26) + 'a';
        } else if (c >= '0' && c <= '9') {
            // Chiffre
            message[i] = ((c - '0' - cle + 10) % 10) + '0';
        }
        // Autres caractères : inchangés
        i++;
    }
}



void affichage() {
    char chaine[100];
    int cle;
    int choix;

    printf("-=-=- Algorithme de chiffrement Cesar -=-=- \n\n");
    do {
        printf("--- Menu ---\n\n");
        printf("1. Definir un nouveau message\n");
        printf("2. Tester le formt du message\n");
        printf("3. Chiffrer le message\n");
        printf("4. Déchiffrer le message\n");
        printf("0. Quitter\n");
        printf("Votre choix : ");
        scanf("%d", &choix);
        getchar(); // Pour consommer le \n restant après scanf

        switch (choix) {
            case 1:
                printf("Entrez un nouveau message a chiffrer : ");
                fgets(chaine, sizeof(chaine), stdin);
                break;


            case 2:
                
                if (estAlphanumerique(chaine)==1) {
                    printf("Le message est alphanumerique.\n");
                } else {
                    printf("Le message contient des caracteres non alphanumeriques.\n");
                }
                break;


            case 3:

                printf("Entrez une cle de chiffrement : ");
                scanf("%d", &cle);
                getchar();

                chiffrerCesar(chaine, cle);
                printf("Message chiffre : %s\n", chaine);
                break;

            case 4:

                printf("Entrez une cle de dechiffrement (similaire a la cle de chiffrement): ");
                scanf("%d", &cle);
                getchar();

                dechiffrerCesar(chaine, cle);
                printf("Message dechiffre : %s\n", chaine);
                break;

            case 0:
                printf("Fermeture du programme.\n");
                break;

            default:
                printf("Choix invalide, veuillez reessayer.\n");
        }
    } while (choix != 0);

}


void main() {
    affichage();
}
