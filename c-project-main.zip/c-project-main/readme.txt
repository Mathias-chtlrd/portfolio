Mode d’emploi
Ce programme permet de :
- Saisir un message
- Vérifier s’il est bien alphanumérique
- Le chiffrer à l’aide de l’algorithme de César
- Le déchiffrer avec la même clé
Lancer le programme
- gcc -o cesar projet.c
- ./cesar
Menu principal
1) Definir un nouveau message
2) Tester le format du message
3) Chiffrer le message
4) Déchiffrer le message
5) Quitter

1) Définir un nouveau message
- Entrez le message à traiter
- Exemple : Bonjour123
2) Tester le format du message
- Vérifie que le message contient seulement des lettres et des chiffres.
- Résultat :
- Si alphanumérique : Le message est alphanumerique.
- Sinon : Le message contient des caracteres non alphanumeriques.
3) Chiffrer le message
- Entrez une clé de chiffrement (un entier).
- Exemple : 3
- Le programme applique l’algorithme de César :
- Les lettres et chiffres sont décalés de 3.
- Résultat : Message chiffre : Erqmrxu456
4) Déchiffrer le message
- Entrez la même clé utilisée lors du chiffrement.
- Le programme décrypte le message avec un décalage inverse.
- Résultat : Message dechiffre : Bonjour123
5) Quitter
- Termine l’exécution du programme.